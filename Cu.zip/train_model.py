# train_model.py
import pandas as pd
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# Load dataset
df = pd.read_csv("KaggleV2-May-2016.csv")

# Preprocess
df["No-show"] = df["No-show"].map({"Yes": 1, "No": 0})

features = ["Age", "Scholarship", "Hipertension", "Diabetes", "Alcoholism", "SMS_received"]
X = df[features]
y = df["No-show"]

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save model
os.makedirs("app/models", exist_ok=True)
joblib.dump(model, "app/models/noshow_model.pkl")
print("Model trained and saved to app/models/noshow_model.pkl")
