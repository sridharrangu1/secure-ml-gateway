# app/roles.py
PERMISSIONS = {
    "admin": ["predict_noshow", "flag_anomaly"],
    "doctor": ["predict_noshow"],
    "nurse": ["predict_noshow"]
}

